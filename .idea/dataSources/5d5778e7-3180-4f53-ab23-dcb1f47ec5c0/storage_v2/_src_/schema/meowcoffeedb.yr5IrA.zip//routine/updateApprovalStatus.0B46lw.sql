create
    definer = root@localhost procedure updateApprovalStatus(IN dd_Approval varchar(10), IN dd_Id bigint)
begin
    declare real_quantity int;
    declare stk_id varchar(12);
    declare cur_status varchar(10);

    select realStkQuantity, stkId, ddApproval into real_quantity, stk_id, cur_status
    from due_diligence where ddId = dd_Id;

    if dd_Approval = 'APPROVED' and cur_status = 'PENDING' then
        update stock set stkQuantity = real_quantity
        where stkId = stk_id;
        update due_diligence set ddApproval = dd_Approval
        where ddId= dd_Id;
    elseif dd_Approval = 'REJECTED' and cur_status= 'PENDING' then
        update due_diligence set ddApproval = dd_Approval
        where ddId= dd_Id;
    end if;
end;

