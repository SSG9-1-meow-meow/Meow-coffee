create definer = root@localhost view managers as
select `meowcoffeedb`.`users`.`userId`        AS `userId`,
       `meowcoffeedb`.`users`.`userName`      AS `userName`,
       `meowcoffeedb`.`users`.`userPwd`       AS `userPwd`,
       `meowcoffeedb`.`users`.`userCode`      AS `userCode`,
       `meowcoffeedb`.`users`.`userPhone`     AS `userPhone`,
       `meowcoffeedb`.`users`.`userEmail`     AS `userEmail`,
       `meowcoffeedb`.`users`.`userImgPath`   AS `userImgPath`,
       `meowcoffeedb`.`users`.`userJoinDate`  AS `userJoinDate`,
       `meowcoffeedb`.`users`.`userLastLogin` AS `userLastLogin`,
       `meowcoffeedb`.`users`.`userRole`      AS `userRole`,
       `meowcoffeedb`.`users`.`userStatus`    AS `userStatus`
from `meowcoffeedb`.`users`
where ((`meowcoffeedb`.`users`.`userStatus` = 'APPROVAL') and
       (`meowcoffeedb`.`users`.`userRole` in ('MANAGER', 'ADMIN')));

