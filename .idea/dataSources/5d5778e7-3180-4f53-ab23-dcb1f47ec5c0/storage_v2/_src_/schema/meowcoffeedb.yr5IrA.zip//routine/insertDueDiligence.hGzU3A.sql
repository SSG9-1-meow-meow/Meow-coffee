create
    definer = root@localhost procedure insertDueDiligence(IN stk_Id varchar(12), IN real_StkQuantity int,
                                                          IN dd_Log varchar(255), IN ma_Id varchar(30))
begin
    declare status varchar(10);
    declare quantity int;
    select stk.stkQuantity into quantity
    from stock stk
    where stk.stkId = stk_Id;
    if quantity = real_StkQuantity then set status = 'CORRECT';
    else set status = 'INCORRECT';
    end if;
    insert into due_diligence (stkId, ddStatus, maId, ddLog, realStkQuantity)
    values(stk_Id, status, ma_id, dd_Log, real_StkQuantity);

end;

