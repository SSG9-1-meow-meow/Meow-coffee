create
    definer = root@localhost procedure updateDueDiligence(IN dd_Id bigint, IN stk_Quantity int, IN real_StkQuantity int,
                                                          IN dd_Log varchar(255))
begin
    declare status varchar(10);

    if stk_Quantity = real_StkQuantity then set status = 'CORRECT';
    else set status = 'INCORRECT';
    end if;

    update due_diligence set ddStatus=status, ddLog = dd_Log,
                             ddUpdateDate = now(), realStkQuantity = real_StkQuantity
    where  ddId = dd_Id and isDelete = 0;

end;

