create definer = root@localhost view companies as
select `meowcoffeedb`.`users`.`userId`                           AS `userId`,
       `meowcoffeedb`.`users`.`userCompanyName`                  AS `userCompanyName`,
       `meowcoffeedb`.`users`.`userName`                         AS `userName`,
       `meowcoffeedb`.`users`.`userPwd`                          AS `userPwd`,
       `meowcoffeedb`.`users`.`userPhone`                        AS `userPhone`,
       `meowcoffeedb`.`users`.`userEmail`                        AS `userEmail`,
       `meowcoffeedb`.`users`.`userCode`                         AS `userCode`,
       `meowcoffeedb`.`users`.`userRoadAddr`                     AS `userRoadAddr`,
       `meowcoffeedb`.`users`.`userDetailAddr`                   AS `userDetailAddr`,
       `meowcoffeedb`.`users`.`userImgPath`                      AS `userImgPath`,
       `meowcoffeedb`.`users`.`userJoinDate`                     AS `userJoinDate`,
       (`meowcoffeedb`.`users`.`userJoinDate` + interval 1 year) AS `date_add(userJoinDate, interval 1 year)`,
       `meowcoffeedb`.`users`.`userLastLogin`                    AS `userLastLogin`,
       `meowcoffeedb`.`users`.`userStatus`                       AS `userStatus`
from `meowcoffeedb`.`users`
where ((`meowcoffeedb`.`users`.`userStatus` = 'APPROVAL') and (`meowcoffeedb`.`users`.`userRole` = 'COMPANY'));

